# -*- coding: utf-8 -*-
{
    'name': "ACCOUNT INVOICE PDF WITH QR",
    'author':
        'Enzapps',
    'summary': """
This module is for creating api for Invoices.
""",

    'description': """
        This module consist of track page of cargo which extend the website.
        It consist of 2 tabs Brief and History
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['base','account'],
    "images": ['static/description/icon.png'],
    'data': [
              'views/configuration.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
