# -*- coding: utf-8 -*-
{
    'name': "NATCOM MAIL subject",
    'author':
        'Enzapps',
    'summary': """
This module is for creating api for Invoices.
""",

    'description': """
        This module consist of track page of cargo which extend the website.
        It consist of 2 tabs Brief and History
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['sale','base','account','mail'],
    "images": ['static/description/icon.png'],
    'data': [
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
