# -*- coding: utf-8 -*-

from . import configuration
from . import res_company
from . import account_tax, account_move
from . import sale_order, sale_order_line
from . import res_partner, product_product
