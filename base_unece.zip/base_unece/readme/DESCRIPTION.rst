This module adds the technical basis for the use of the code lists
standardized by the
`United Nations Economic Commission for Europe <http://www.unece.org>`_
(which has 56 members states in Europe, America and Central Asia, cf
`Wikipedia <https://en.wikipedia.org/wiki/United_Nations_Economic_Commission_for_Europe>`_.
These code lists are sometimes called UNCL (United Nations Code List). UNECE
has standardized code lists for many different things: units of measure,
payment means, modes of transport, packaging, taxes, etc....
