The configuration takes place in the menu
*Settings > Technical > Parameters > UNECE Code Lists*.
