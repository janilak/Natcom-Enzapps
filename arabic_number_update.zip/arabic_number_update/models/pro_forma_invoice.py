from odoo import fields,models
import convert_numbers


class ProFormaInvoice(models.Model):
    _inherit = 'pro.forma.invoice'

    def ar_total_tax(self):
        value = self.advance_amount * 0.15
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar
        return before_ar + '.' + after_ar


