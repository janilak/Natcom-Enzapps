Refer to the usage instructions of the module **account\_invoice\_download**.
