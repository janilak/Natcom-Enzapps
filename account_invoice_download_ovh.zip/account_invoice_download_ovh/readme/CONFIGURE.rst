To configure this module, you need to go to the menu *Invoicing > Configuration > Import Vendor Bills > Download Bills* and create one entry per OVH Account. Select *OVH* as *Backend*.

If you don't already have the required parameters to access the OVH API (Application key, Application secret and Consumer key) with the appropriate access level on the APIs used by this module, clic on the button **Generate OVH API Credentials** once *OVH* is selected as Backend and follow the instructions of the wizard.
