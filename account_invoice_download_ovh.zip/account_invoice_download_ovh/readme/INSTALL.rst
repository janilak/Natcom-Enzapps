Before installing the module, you need to install the `OVH python lib <https://github.com/ovh/python-ovh>`_ via the following command:

.. code::

  sudo pip3 install --upgrade ovh
