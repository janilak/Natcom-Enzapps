The new configuration parameter *XML Format embedded in PDF invoice*
is available in the menu *Invoicing > Configuration > Settings*.
