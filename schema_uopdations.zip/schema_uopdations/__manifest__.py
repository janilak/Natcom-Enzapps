# -*- coding: utf-8 -*-
{
    'name': "Pro Forma Sequence",
    'author':
        'ENZAPPS',
    'summary': """
This module is for Pro Forma Sequence.
""",

    'description': """
        This module is for Pro Forma Sequence.
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['base', 'account'],
    "images": ['static/description/icon.png'],
    'data': [
        'views/schema.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
