from odoo import fields, models, api



class ResPartner(models.Model):
    _inherit = 'res.partner'
    # cust_code = fields.Char(string="ddd")

    def action_schema_update(self):
        for each in self.env['res.partner'].search([('schema_id_no','=',False)]):
            each.write({'type_of_customer':'b_c'})
            each.write({'schema_id':'IQA'})
            if each.cust_code:
              each.write({'schema_id_no':each.cust_code})
            else:
                each.write({'schema_id_no': 'xxxx'})






