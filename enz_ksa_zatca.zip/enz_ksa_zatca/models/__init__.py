# -*- coding: utf-8 -*-

from . import configuration
from . import account_tax
from . import account_move
from . import sale_order
from . import sale_order_line
from . import res_company
from . import res_partner
from . import product_product

