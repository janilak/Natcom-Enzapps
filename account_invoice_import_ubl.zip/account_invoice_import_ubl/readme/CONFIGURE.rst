There is no configuration specific to this module. Please refer to the configuration section of the modules
*account_invoice_import* and *account_tax_unece*.
