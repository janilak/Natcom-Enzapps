{
    "name": "Natcom Credit Report",
    "version": "14.0",
    "category": "Accounting",
    "license": "",
    "summary": "Natcom Credit Report",
    "author": "Enzapps Private Limited",
    "website": "https://www.enzapps.com",
    "depends": ["base","account"],
    "data": [
        'report/reports_header_new_view.xml',
        'report/report.xml',
        'report/reports_no_new_view.xml',
    ],
    "qweb": [
    ],
    "installable": True,
}