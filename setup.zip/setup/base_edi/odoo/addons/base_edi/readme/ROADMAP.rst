* implement new generic features around this
* integrate existing modules with this
