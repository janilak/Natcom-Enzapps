The development of this module has been financially supported by:

* Camptocamp
