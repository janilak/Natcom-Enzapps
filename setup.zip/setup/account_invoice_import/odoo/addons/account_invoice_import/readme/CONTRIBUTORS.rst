* Alexis de Lattre <alexis.delattre@akretion.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Nicolas JEUDY <https://github.com/njeudy>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Ronald Portier <ronald@therp.nl>
