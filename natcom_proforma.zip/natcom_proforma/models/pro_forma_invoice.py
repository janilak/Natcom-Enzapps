from odoo import models,fields,api
from datetime import datetime
import convert_numbers


from uuid import uuid4
import qrcode
import base64
import logging

from lxml import etree

class ProFormaInvoice(models.Model):
    _inherit = 'pro.forma.invoice'

    system_inv_no_ar = fields.Char()
    invoice_date_time = fields.Date('Invoice Date',required=1)
    invoice_date_time_ar = fields.Char('Invoice Date Arabic')
    payment_mode = fields.Char(string='Payment Mode')
    sales_man = fields.Char()
    address_contact = fields.Char()
    address_contact_ar = fields.Char()
    so_number = fields.Char(string='SO Number')
    customer_po = fields.Char(string='Customer PO Number')
    contact = fields.Char(string='Contact Eng')
    contact_address = fields.Char(string='Contact Address')
    datetime_field = fields.Datetime(string="Create Date", default=lambda self: fields.Datetime.now())
    decoded_data = fields.Char('Decoded Data')
    ubl_preview = fields.Integer(string="Test")
    debit_note = fields.Boolean(default=False)
    credit_note = fields.Boolean(default=False)
    qr_image = fields.Binary(string="QR Image")
    uuid = fields.Char('UUID', size=50, index=True, default=lambda self: str(uuid4()), copy=False)

    def testing(self):
        leng = len(self.company_id.name)
        company_name = self.company_id.name
        if 42 > leng:
            for r in range(42-leng):
                if len(company_name) != 42:
                   company_name +=' '
                else:
                    break
        else:
            if 42 < leng:
                company_name = company_name[:42]
        vat_leng = len(self.company_id.vat)
        vat_name = self.company_id.vat
        if 17 > vat_leng:
            for r in range(15 - vat_leng):
                if len(vat_name) != 15:
                    vat_name += ' '
                else:
                    break
        else:
            if 17 < leng:
                vat_name = vat_name[:17]

        amount_total = str(self.amount_total)
        amount_leng = len(str(self.amount_total))
        if len(amount_total) < 17:
            for r in range(17-amount_leng):
                if len(amount_total) != 17:
                   amount_total +=' '
                else:
                    break

        tax_leng = len(str(self.amount_tax))
        amount_tax_total = str(self.amount_tax)
        if len(amount_tax_total) < 17:
            for r in range(17-tax_leng):
                if len(amount_tax_total) != 17:
                   amount_tax_total +=' '
                else:
                    break
        TimeAndDate = str(self.invoice_date_time) + "T" + str(self.datetime_field.time()) + "Z"
        time_length = len(str(self.invoice_date_time) + "T" + str(self.datetime_field.time()) + "Z")

        Data = str(chr(1)) + str(chr(leng)) + self.company_id.name
        Data += (str(chr(2))) + (str(chr(vat_leng))) + vat_name
        Data += (str(chr(3))) + (str(chr(time_length))) + TimeAndDate
        Data += (str(chr(4))) + (str(chr(len(str(self.amount_total))))) + str(self.amount_total)
        Data += (str(chr(5))) + (str(chr(len(str(self.amount_tax))))) + str(self.amount_tax)
        data = Data
        import base64
        print(data)
        mou = base64.b64encode(bytes(data, 'utf-8'))
        self.decoded_data = str(mou.decode())
        qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=20,
                border=4,
            )
        data_im = str(mou.decode())
        qr.add_data(data_im)
        qr.make(fit=True)
        img = qr.make_image()

        import io
        import base64

        temp = io.BytesIO()
        img.save(temp, format="PNG")
        qr_image = base64.b64encode(temp.getvalue())
        self.qr_image = qr_image
        print(mou.decode())
        return str(mou.decode())



    def invoice_date_time_test(self):
        # return self.invoice_date_time.split(' ')[0]
        # return self.invoice_date_time.split(' ')[0]
        return self.invoice_date_time

    def ar_discount_value(self):
        value = self.discount
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar + ' SR'
        return before_ar + '.' + after_ar + ' SR'

    def ar_advance(self):
        value = self.advance_amount
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar + ' SR'
        return before_ar + '.' + after_ar + ' SR'

    def ar_invoice_name(self,name):

        interger_part = name[3:]
        interger_part_arabic = convert_numbers.english_to_arabic(interger_part)
        # inv_name_arabic = GoogleTranslator(source='auto', target='ar').translate(name[:3])
        inv_name_arabic = ""
        # return  inv_name_arabic+interger_part_arabic
        return  inv_name_arabic


    def invoice_date_times(self):
        # return self.invoice_date_time.split(' ')[0]
        return self.invoice_date_time

    def ar_invoice_date(self):
        m = str(self.invoice_date)
        if m.split('-'):
            interger_part_arabic=''
            for each in m.split('-'):
                if interger_part_arabic:
                    interger_part_arabic = interger_part_arabic+'-'
                interger_part_arabic += convert_numbers.english_to_arabic(int(each))

        return interger_part_arabic

    def total_amount_to_words_natcom(self):
        for invoice in self:
            return invoice.currency_id.amount_to_text(invoice.amount_untaxed)

    def total_amount_to_words_natcom_arabic(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_untaxed)
            # amount_arabic = GoogleTranslator(source='auto', target='ar').translate(amount_total_words)
            amount_arabic ="TESTING"
            return amount_arabic


    def total_amount_to_words_tax(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_total)
            return  amount_total_words

    def total_amount_to_words_tax_arabic(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_total)
            # amount_total = GoogleTranslator(source='auto', target='ar').translate(amount_total_words)
            amount_total = "fddgdfgfd"
            return  amount_total

    def ar_mobile(self):
        a = self.partner_id.mobile
        ar_mobile = convert_numbers.english_to_arabic(a)
        return ar_mobile

    def ar_total_tax(self):
        value = self.amount_untaxed * 0.15
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar
        return before_ar + '.' + after_ar

    def amount_total_arabic(self):
        value = self.amount_total
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar
        return before_ar + '.' + after_ar

    def amount_untaxed_convert(self):
        value = self.amount_untaxed
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        # ar_total_tax_amount = before_ar + '.' + after_ar
        return before_ar + '.' + after_ar

    def ar_advances(self):
        value = self.advance_amount
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar
        return before_ar + '.' + after_ar

        # def ar_invoice_name(self,name):
        #     translated = GoogleTranslator(source='auto', target='ar').translate(name)
        #     print(translated,'name')
        #     return translated

    @api.onchange('partner_id')
    def compute_salesman(self):
        self.sales_man = self.partner_id.sales_man


class ProFormaInvoiceLine(models.Model):
    _inherit = 'pro.forma.invoice.line'


    def total_amount(self):
        total = 0.00
        total_amount = 0.00
        for vat in self:

            total = vat.price_subtotal * 0.15
            total_amount =total + vat.price_subtotal
        return total_amount


    def product_arabic(self):
        for products in self:
            product = products.product_id.name
            product_template = self.env['product.template'].search([('name','=',product)])
            for ar in product_template:
                return ar.arabic


    def line_price_subtotal(self):
        for price in self:
            if price.discount != 0.00:
                qty_price = price.quantity * price.price_unit
                return qty_price
            else:
                return price.price_subtotal









class ResPartner(models.Model):
    _inherit = 'res.partner'

    sales_man = fields.Char()

# class ProFormaCreditReason(models.TransientModel):
#     _inherit = 'pro.forma.credit.reason'
#
#     def reverse(self):
#         referance = 'Reversal of:'+self.pro_forma_id.name
#         if self.name != False:
#             referance = referance + ',' + self.name
#         invoice_list = []
#         for line in self.pro_forma_id.invoice_line_ids:
#             invoice_line = (0,0,{
#                 'product_id':line.product_id.id,
#                 'name':line.name,
#                 'vat_category':line.vat_category,
#                 'discount':line.discount,
#                 'quantity':line.quantity,
#                 'price_unit':line.price_unit,
#                 'tax_ids':[(6,0,line.tax_ids.ids)],
#                 'price_subtotal':line.price_subtotal
#             })
#             invoice_list.append(invoice_line)
#         self.pro_forma_id.credit_id = self.env['pro.forma.invoice'].create({
#             'partner_id':self.pro_forma_id.partner_id.id,
#             'payment_reference':self.pro_forma_id.payment_reference,
#             'partner_bank_id':self.pro_forma_id.partner_bank_id,
#             'invoice_date':self.pro_forma_id.invoice_date,
#             'arabic_date':self.pro_forma_id.arabic_date,
#             'invoice_payment_term_id':self.pro_forma_id.invoice_payment_term_id.id,
#             'invoice_due_date':self.pro_forma_id.invoice_due_date,
#             'invoice_line_ids':invoice_list,
#             'ar_amount_untaxed':self.pro_forma_id.ar_amount_untaxed,
#             'ar_discount':self.pro_forma_id.ar_discount,
#             'ar_amount_tax':self.pro_forma_id.ar_amount_tax,
#             'ar_amount_total':self.pro_forma_id.ar_amount_total,
#             'amount_total_word_ar':self.pro_forma_id.amount_total_word_ar,
#             'state':self.pro_forma_id.state,
#             'advance_amount':self.pro_forma_id.advance_amount,
#             'advance_bool':self.pro_forma_id.advance_bool,
#             'company_id':self.pro_forma_id.company_id.id,
#             'advance_id':self.pro_forma_id.advance_id.id,
#             'currency_id':self.pro_forma_id.currency_id.id,
#             'pro_invoice_type':'credit',
#             'ref':referance,
#             'system_inv_no_ar':self.system_inv_no_ar,
#             'invoice_date_time':self.invoice_date_time,
#             'invoice_date_time_ar':self.invoice_date_time_ar,
#             'payment_mode':self.payment_mode,
#             'sales_man':self.sales_man,
#             'address_contact':self.address_contact,
#             'address_contact_ar':self.address_contact_ar,
#             'so_number':self.so_number,
#             'customer_po':self.customer_po,
#             'contact':self.contact,
#             'contact_address':self.contact_address,
#         }).id
#
#
