# -*- coding: utf-8 -*-
{
    'name': "Natcom Sales Return",
    'author':
        'Enzapps',
    'summary': """
This module is for creating api for Invoices.
""",

    'description': """
        This module consist of track page of cargo which extend the website.
        It consist of 2 tabs Brief and History
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['sale','purchase','base','account','natcomjson'],
    "images": ['static/description/icon.png'],
    'data': [
              'security/ir.model.access.csv',
              'data/sheduled_action.xml',
              'views/return.xml',
              'views/json_calling.xml'
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
