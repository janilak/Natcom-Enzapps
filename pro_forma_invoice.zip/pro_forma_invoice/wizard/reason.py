from odoo import fields,models

class ProFormaCreditReason(models.TransientModel):
    _name = 'pro.forma.credit.reason'

    name = fields.Char()
    pro_forma_id = fields.Many2one('pro.forma.invoice')

    def reverse(self):
        referance = 'Reversal of:'+self.pro_forma_id.name
        if self.name != False:
            referance = referance + ',' + self.name
        invoice_list = []
        for line in self.pro_forma_id.invoice_line_ids:
            invoice_line = (0,0,{
                'product_id':line.product_id.id,
                'name':line.name,
                'vat_category':line.vat_category,
                'discount':line.discount,
                'quantity':line.quantity,
                'price_unit':line.price_unit,
                'tax_ids':[(6,0,line.tax_ids.ids)],
                'price_subtotal':line.price_subtotal
            })
            invoice_list.append(invoice_line)
        self.pro_forma_id.credit_id = self.env['pro.forma.invoice'].create({
            'partner_id':self.pro_forma_id.partner_id.id,
            'payment_reference':self.pro_forma_id.payment_reference,
            'partner_bank_id':self.pro_forma_id.partner_bank_id,
            'invoice_date':self.pro_forma_id.invoice_date,
            'arabic_date':self.pro_forma_id.arabic_date,
            'invoice_payment_term_id':self.pro_forma_id.invoice_payment_term_id.id,
            'invoice_due_date':self.pro_forma_id.invoice_due_date,
            'invoice_line_ids':invoice_list,
            'ar_amount_untaxed':self.pro_forma_id.ar_amount_untaxed,
            'ar_discount':self.pro_forma_id.ar_discount,
            'ar_amount_tax':self.pro_forma_id.ar_amount_tax,
            'ar_amount_total':self.pro_forma_id.ar_amount_total,
            'amount_total_word_ar':self.pro_forma_id.amount_total_word_ar,
            'state':self.pro_forma_id.state,
            'advance_amount':self.pro_forma_id.advance_amount,
            'advance_bool':self.pro_forma_id.advance_bool,
            'company_id':self.pro_forma_id.company_id.id,
            'advance_id':self.pro_forma_id.advance_id.id,
            'currency_id':self.pro_forma_id.currency_id.id,
            'pro_invoice_type':'credit',
            'ref':referance,
        }).id
