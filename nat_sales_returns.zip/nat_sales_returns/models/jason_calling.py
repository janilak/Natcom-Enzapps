from odoo import fields, models
import requests
import json
from datetime import datetime, date


class AccountInvoice(models.Model):
    _inherit = "account.move"

    ref_sales_return = fields.Char(string="REF_SALES_RETURN")


class JsonCallSales(models.Model):
    _name = 'json.call.sales'

    name = fields.Char(default="API Calling", required=1)
    normal = fields.Boolean()
    date = fields.Date(default=datetime.now().date(), required=1)
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done')], default='draft')
    system_inv_no = fields.Char()
    invoice_date_time = fields.Char()

    def return_callrequest(self):
        if self.env['return.json.configuration'].search([]):
            link = self.env['return.json.configuration'].search([])[0].name
            responce = requests.get(link)
            from datetime import datetime
            json_data = self.env['json.call.sales'].create({
                'name': 'Invoice Creation on ' + str(datetime.now().date()),
                'date': datetime.now().date(),
            })
            if responce:
                line_data = json.loads(responce.text)
                invoice_no = None
                invoice_date = None
                invoice_length = 0
                for line in line_data:
                    if invoice_length <= 10:
                        old_invoice = self.env['account.move'].search([('system_inv_no', '=', line['InvoiceNo'])])
                        if not old_invoice:
                        # if old_invoice:
                            invoice_length += 1
                            partner_details = self.env['res.partner'].sudo().search(
                                [('name', '=', line['Customer Name'])])
                            if partner_details:
                                partner_id = partner_details

                            invoice_list = []
                            for inv_line in line['Invoice lines']:
                                product = self.env['product.product'].sudo().search(
                                    [('name', '=', inv_line['Product Name'])])
                                invoice_list.append((0, 0, {
                                    'name': inv_line['description'],
                                    'price_unit': inv_line['Price'],
                                    'quantity': inv_line['Quantity'],
                                    'discount': inv_line['Discount'],
                                    'product_uom_id': self.env['uom.uom'].sudo().search(
                                        [('name', '=', inv_line['UoM'])]).id,
                                    'vat_category': inv_line['Vat Category'],
                                    'product_id': product.id,
                                    'tax_ids': [(6, 0, self.env['account.tax'].sudo().search(
                                        [('name', '=', inv_line['Taxes']), ('type_tax_use', '=', 'sale')]).ids)]}))
                            invoice_date = (line['InvoiceDate'].split(" ")[0]).split("/")
                            day = invoice_date[0]
                            month = invoice_date[1]
                            year = invoice_date[2]
                            account_move = self.env['account.move'].sudo().create({
                                # 'partner_id': partner_id.id,
                                # 'move_type': 'out_refund',
                                # 'invoice_line_ids': invoice_list,
                                # 'payment_mode': line['Payment Mode'],
                                # 'contact': line['Address Contact'],
                                # 'contact_address': line['Address Contact Arabic'],
                                # 'payment_reference': line['payment reference'],
                                # 'invoice_date': year+'-'+month + '-' + day,
                                # 'system_inv_no': line['InvoiceNo'],
                                # 'ref_sales_return': line['REF_SALES_RETURN'],
                                # 'system_inv_no_ar': line['InvoiceNoArabic'],
                                # 'invoice_date_time': line['InvoiceDate'],
                                # 'invoice_date_time_ar': line['InvoiceDateArabic'],
                                # 'sales_man': line['Salesman Name'],
                                # 'so_number': line['SO No'],
                                # 'address_contact': line['Address Contact'],
                                # 'address_contact_ar': line['Address Contact Arabic'],
                                'partner_id': partner_id[0].id,
                                'invoice_line_ids': invoice_list,
                                'payment_mode': line['Payment Mode'],
                                'move_type': 'out_refund',
                                'contact': line['Address Contact'],
                                'contact_address': line['Address Contact Arabic'],
                                'payment_reference': line['payment reference'],
                                'invoice_date': year+'-'+month+'-'+day ,
                                'system_inv_no':line['InvoiceNo'],
                                'invoice_nat_time':line['INVOICE_DATETIME'],
                                'customer_po': line['PONO'],
                                'ar_amount_untaxed': line['Word without vat'],
                                'amount_in_word_ar': line['Word with vat'],
                                'system_inv_no_ar':line['InvoiceNoArabic'],
                                'invoice_date_time':line['InvoiceDate'],
                                'advance_with_vat':line['ADVANCE_WITH_VAT'],
                                'a_advance_with_vat':line['A_ADVANCE_WITH_VAT'],
                                'invoice_date_time_ar':line['InvoiceDateArabic'],
                                'sales_man':line['Salesman Name'],
                                'so_number':line['SO No'],
                                'curr_code':line['CURR_CODE'],
                                'remarks':line['ANNOTATION'],
                                'advance': line['ADVANCE'],
                                'ar_advance': line['ADVANCE_A'],
                                'exchg_rate': line['EXCHG_RATE'],
                                'discount_value': line['DISCOUNT_VALUE'],
                                'discount_value_a': line['DISCOUNT_VALUE_A'],
                                'word_without_vat_english': line['Word without vat english'],
                                'word_with_vat_english': line['Word with vat english'],
                                'address_contact':line['Address Contact'],
                                'address_contact_ar':line['Address Contact Arabic'],
                            })
                            invoice_no = line['InvoiceNo']
                            invoice_date = line['InvoiceDate']
                            if account_move:
                                import datetime
                                date = datetime.date(account_move.invoice_date.year, account_move.invoice_date.month,
                                                     account_move.invoice_date.day)
                                # month = invoice_date[0]
                                # day = invoice_date[1]
                                # year = invoice_date[2]
                                tota = line['INVOICE_DATETIME'].rsplit(' ')[1].rsplit(':')[0]
                                hr = int(tota[0])
                                min = int(tota[1])
                                # sec = tota[2]
                                import datetime
                                times = datetime.time(hr,min)
                                # datetime.time(each.datetime_field.time().hour, each.datetime_field.time().minute)
                                account_move.invoice_nat_times = datetime.datetime.combine(account_move.invoice_date, times)

                            if account_move.ref_sales_return:
                                reversed_inv = self.env['account.move'].search([('system_inv_no','=',account_move.ref_sales_return)])
                                # reversed_inv = self.env['account.move'].browse(146)
                                account_move.reversed_entry_id = reversed_inv
                            account_move.action_post()
                        if line_data:
                            json_data.system_inv_no = invoice_no
                            json_data.invoice_date_time = invoice_date
