#. Go to the menu *Accounting > Configuration > Management > Payment Methods*
#. On each payment method, select the appropriate value for the *UNECE Code*.
