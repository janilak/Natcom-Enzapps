# -*- coding: utf-8 -*-
{
    'name': "Removing old invoice number",
    'author':
        'Enzapps Private Limited',
    'summary': """
This module will help to Supplier domain in Lead
""",

    'description': """
This module will help to Supplier domain in Lead
    """,
    'website': "",
    'category': 'base',
    'version': '14.0',
    'depends': ['base','account',"stock","sale"],
    "images": ['static/description/icon.png'],
    'data': [
        'views/demo_sales.xml'
           ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
