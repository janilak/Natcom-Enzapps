from odoo import fields, models,api
from odoo.exceptions import UserError

from uuid import uuid4
import qrcode
import base64
import logging

from lxml import etree

from odoo import fields, models
import requests
import json
from datetime import datetime,date


class ResPartner(models.Model):
    _inherit = 'res.partner'

    compute_test_send_test = fields.Boolean(string='New')

