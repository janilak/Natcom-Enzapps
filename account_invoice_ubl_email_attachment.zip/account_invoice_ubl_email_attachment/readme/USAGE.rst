In the invoice form click on button `Send & Print`.
