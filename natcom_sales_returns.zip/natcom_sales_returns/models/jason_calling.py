from odoo import fields, models
import requests
import json
from datetime import datetime, date


class AccountInvoice(models.Model):
    _inherit = "account.move"

    ref_sales_return = fields.Char(string="REF_SALES_RETURN")


class JsonCallSales(models.Model):
    _name = 'json.call.sales'

    name = fields.Char(default="API Calling", required=1)
    normal = fields.Boolean()
    date = fields.Date(default=datetime.now().date(), required=1)
    state = fields.Selection([('draft', 'Draft'), ('done', 'Done')], default='draft')
    system_inv_no = fields.Char()
    invoice_date_time = fields.Char()

    def return_callrequest(self):
        if self.env['return.json.configuration'].search([]):
            link = self.env['return.json.configuration'].search([])[0].name
            responce = requests.get(link)
            json_data = self.env['json.call.sales'].create({
                'name': 'Invoice Creation on ' + str(datetime.now().date()),
                'date': datetime.now().date(),
            })
            if responce:
                line_data = json.loads(responce.text)
                invoice_no = None
                invoice_date = None
                invoice_length = 0
                for line in line_data:
                    if invoice_length <= 10:
                        old_invoice = self.env['account.move'].search([('system_inv_no', '=', line['InvoiceNo'])])
                        if not old_invoice:
                        # if old_invoice:
                            invoice_length += 1
                            partner_details = self.env['res.partner'].sudo().search(
                                [('name', '=', line['Customer Name'])])
                            if partner_details:
                                partner_id = partner_details

                            invoice_list = []
                            for inv_line in line['Invoice lines']:
                                product = self.env['product.product'].sudo().search(
                                    [('name', '=', inv_line['Product Name'])])
                                invoice_list.append((0, 0, {
                                    'name': inv_line['description'],
                                    'price_unit': inv_line['Price'],
                                    'quantity': inv_line['Quantity'],
                                    'discount': inv_line['Discount'],
                                    'product_uom_id': self.env['uom.uom'].sudo().search(
                                        [('name', '=', inv_line['UoM'])]).id,
                                    'vat_category': inv_line['Vat Category'],
                                    'product_id': product.id,
                                    'tax_ids': [(6, 0, self.env['account.tax'].sudo().search(
                                        [('name', '=', inv_line['Taxes']), ('type_tax_use', '=', 'sale')]).ids)]}))
                            invoice_date = (line['InvoiceDate'].split(" ")[0]).split("/")
                            day = invoice_date[0]
                            month = invoice_date[1]
                            year = invoice_date[2]
                            account_move = self.env['account.move'].sudo().create({
                                'partner_id': partner_id.id,
                                'move_type': 'out_refund',
                                'invoice_line_ids': invoice_list,
                                'payment_mode': line['Payment Mode'],
                                'contact': line['Address Contact'],
                                'contact_address': line['Address Contact Arabic'],
                                'payment_reference': line['payment reference'],
                                'invoice_date': year+'-'+month + '-' + day,
                                'system_inv_no': line['InvoiceNo'],
                                'ref_sales_return': line['REF_SALES_RETURN'],
                                'system_inv_no_ar': line['InvoiceNoArabic'],
                                'invoice_date_time': line['InvoiceDate'],
                                'invoice_date_time_ar': line['InvoiceDateArabic'],
                                'sales_man': line['Salesman Name'],
                                'so_number': line['SO No'],
                                'address_contact': line['Address Contact'],
                                'address_contact_ar': line['Address Contact Arabic'],
                            })
                            invoice_no = line['InvoiceNo']
                            invoice_date = line['InvoiceDate']
                            if account_move.ref_sales_return:
                                reversed_inv = self.env['account.move'].search([('system_inv_no','=',account_move.ref_sales_return)])
                                # reversed_inv = self.env['account.move'].browse(146)
                                account_move.reversed_entry_id = reversed_inv
                            account_move.action_post()
                        if line_data:
                            json_data.system_inv_no = invoice_no
                            json_data.invoice_date_time = invoice_date
