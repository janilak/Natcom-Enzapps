The migration of this module from 13.0 to 14.0 was financially supported by Camptocamp
