from odoo import fields,models,api
from datetime import datetime,date
from dateutil.relativedelta import relativedelta


class JsonConfiguration(models.Model):
    _inherit = 'json.configuration'

    no_of_invoices = fields.Integer(string="No If Invoice")

