import requests
from odoo import http
from odoo.http import request
import json
import decimal
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

import werkzeug.urls
import werkzeug.utils
from werkzeug.exceptions import BadRequest
# import yaml
import time
from datetime import datetime

from odoo import http
from odoo.addons.sale.controllers.onboarding import OnboardingController


class Invoicedetails(http.Controller):

    @http.route('/invoicedetails', auth='public', methods=['GET'])
    def salesorders(self, **kw):
        cargo_status_list = http.request.env['account.move'].sudo().search(
            [])[0]
        products_list = []
        for cargo_status in cargo_status_list:
            invoice_list = []
            for line in cargo_status.invoice_line_ids:
                tax_name = None
                if len(line.tax_ids) > 0:
                    tax_name = line.tax_ids[0].name
                invoice_list.append({
                    "Product Name": line.product_id.name,
                    "description": line.name,
                    "UoM": line.product_id.uom_id.name,
                    "Vat Category": line.vat_category,
                    "Quantity": line.quantity,
                    "Price": line.price_unit,
                    "Discount": line.discount,
                    "Taxes": tax_name,
                    "Subtotal": line.price_subtotal,
                })
            products_list.append({
                "Customer Name": cargo_status.partner_id.name,
                "Mobile Number": cargo_status.partner_id.mobile,
                "Street Name": cargo_status.partner_id.street,
                "Street2 Name": cargo_status.partner_id.street2,
                "City": cargo_status.partner_id.city,
                "State Name": cargo_status.partner_id.state_id.name,
                "PIN CODE": cargo_status.partner_id.zip,
                "Country": cargo_status.partner_id.country_id.name,
                "VAT No": cargo_status.partner_id.vat,
                "Type of customer": cargo_status.partner_id.type_of_customer,
                "schemeID": cargo_status.partner_id.schema_id,
                "scheme Number": cargo_status.partner_id.schema_id_no,
                "Building Number": cargo_status.partner_id.building_no,
                "Plot Identification": cargo_status.partner_id.plot_id,
                "payment reference": cargo_status.payment_reference,
                "Payment Mode": cargo_status.payment_mode,
                "Invoice Type": cargo_status.move_type,
                "Untaxed Amount": cargo_status.amount_untaxed,
                "tax amount": cargo_status.amount_tax,
                "Amount Total": cargo_status.amount_total,
                "Amount Due": cargo_status.amount_residual,
                "InvoiceNo": cargo_status.name,
                "InvoiceDate": cargo_status.invoice_date.isoformat(),
                "Invoice lines":invoice_list,
            })
        data = products_list

        # return json.dumps({cargo_status})
        def dec_serializer(self):
            if isinstance(self, decimal.Decimal):
                return float(self)

        return json.dumps(data, default=dec_serializer(self))

    @http.route('/invoicecreate', auth='public', methods=['GET'])
    def estimate_create_orders(self, **rec):

        responce = requests.get("http://rehlaapi.native-tech.co/api/GetTripsReportForERP")

