from . import edi_backend
from . import res_partner
