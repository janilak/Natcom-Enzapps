#. Go to *Contacts > Configuration > Bank Accounts > Banks*.
#. Create or modify a bank.
#. Put the corresponding code for that bank in the field "Code".
