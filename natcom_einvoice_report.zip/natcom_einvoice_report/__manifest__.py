# -*- coding: utf-8 -*-
{
    'name': "Natcom E-Invoice Report",
    'author':
        'ENZAPPS',
    'summary': """
This module is for printing E-Invoice report for Natcom.
""",

    'description': """
        This module is for printing E-Invoice report for Natcom.
    """,
    'website': "",
    'category': 'base',
    'version': '12.0',
    'depends': ['base',
                'account',
                'uom_unece',
                'base_unece',
                'account_tax_unece',
                'base_vat_sanitized',
                'onchange_helper',
                'base_iban',
                'base_bank_from_iban',
                'base_business_document_import',
                'account_invoice_import',
                'base_ubl_payment',
                'account_payment_partner',
                'account_invoice_import_ubl',
                'account_invoice_ubl','sale',
                'purchase','stock',
                'arabic_numbers',
                'arabic_strings',],
    # 'depends': ['base','account','uom_unece','base_unece','account_tax_unece','base_vat_sanitized','onchange_helper','base_iban','base_bank_from_iban','base_business_document_import','account_invoice_import','base_ubl_payment','account_payment_partner','account_invoice_import_ubl','account_invoice_ubl','sale','purchase','stock','arabic_numbers','arabic_strings',],
    'data': [
            # 'views/account_invoice.xml',
            'views/account_move.xml',
            'reports/reports.xml',
            # 'reports/reports_view.xml',
            # 'reports/reports_no_view.xml',
            'reports/reports_view_new.xml',
            'reports/reports_no_new_view.xml',
            # 'reports/report_1.xml',
            # 'reports/report_1_view.xml',
            # 'reports/report_view_1.xml',


    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
}
