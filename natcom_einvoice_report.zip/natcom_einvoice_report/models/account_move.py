from odoo import fields,models,api
import convert_numbers
# from deep_translator import GoogleTranslator
from uuid import uuid4
import qrcode
from odoo.exceptions import UserError

import base64
import logging

from lxml import etree

logger = logging.getLogger(__name__)

class AccountMove(models.Model):
    _inherit = 'account.move'

    so_number = fields.Char(string='SO Number')
    customer_po = fields.Char(string='Customer PO Number')
    contact = fields.Char(string='Contact Eng')
    contact_address = fields.Char(string='Contact Address')
    datetime_field = fields.Datetime(string="Create Date", default=lambda self: fields.Datetime.now())
    decoded_data = fields.Char('Decoded Data')
    ubl_preview = fields.Integer(string="Test")
    debit_note = fields.Boolean(default=False)
    credit_note = fields.Boolean(default=False)
    qr_image = fields.Binary(string="QR Image")
    uuid = fields.Char('UUID', size=50, index=True, default=lambda self: str(uuid4()), copy=False)



    def invoice_date_times(self):
        # return self.invoice_date_time.split(' ')[0]
        return self.invoice_date_time


    # def action_post(self):
    #     res = super(AccountMove, self).action_post()
    #     if self.partner_id.type_of_customer == 'b_b':
    #         # print(self.partner_id.type_of_customer)
    #         return self.env.ref('natcom_einvoice_report.natcom_einvoice_report').report_action(self)
    #     # function for b2b invoice
    #     if self.partner_id.type_of_customer == 'b_c':
    #         # print(self.partner_id.type_of_customer)
    #         return self.env.ref('account_invoice_ubl.account_invoices_b2c').report_action(self)
    #     # m = self.attach_ubl_xml_file_button()
    #     # self.ubl_preview = 1
    #     return res

    # def action_post(self):
    #     res = super(AccountMove, self).action_post()
    #     if self.partner_id.type_of_customer == 'b_b':
    #         # For Sending Email After Sheduling Interview
    #         self.admin_mail = self.env['einvoice.admin'].search([])[-1].name.id
    #         template_id = self.env['mail.template'].sudo().search([('name', '=', 'Invoice: Send by email B2B')]).id
    #         template = self.env['mail.template'].browse(template_id)
    #         template.send_mail(self.id, force_send=True)
    #         return self.env.ref('natcom_einvoice_report.natcom_einvoice_report').report_action(self)
    #     if self.partner_id.type_of_customer == 'b_c':
    #         self.admin_mail = self.env['einvoice.admin'].search([])[-1].name.id
    #         template_id = self.env['mail.template'].sudo().search([('name', '=', 'Invoice: Send by email B2C')]).id
    #         template = self.env['mail.template'].browse(template_id)
    #         template.send_mail(self.id, force_send=True)
    #         return self.env.ref('account_invoice_ubl.account_invoices_b2c').report_action(self)
    #     return res

    def action_post(self):
        res = super(AccountMove, self).action_post()
        configuration = self.env['einvoice.config'].search([])
        if self.move_type == 'out_invoice':
            if configuration:
                if self.partner_id.type_of_customer == 'b_b':
                    # For Sending Email After Sheduling Interview
                    if configuration.invoice_email == True:
                        if self.env['einvoice.admin'].search([]):
                            self.admin_mail = self.env['einvoice.admin'].search([])[-1].name.id
                            template_id = self.env['mail.template'].sudo().search(
                                [('name', '=', 'Invoice: Send by email B2B')]).id
                            if template_id:
                                template = self.env['mail.template'].browse(template_id)
                                template.send_mail(self.id, force_send=True)
                            else:
                                raise UserError(
                                    'Please Create an Email Template In the name "Invoice: Send by email B2B" by giving PDF as Default B2B Formate')
                        else:
                            raise UserError('Please Configure the Admin Details to whom the mail need to be sended')
                    if configuration.invoice_print == True:
                        return self.env.ref('natcom_einvoice_report.natcom_einvoice_report').report_action(self)
                if self.partner_id.type_of_customer == 'b_c':
                    if configuration.invoice_email == True:
                        if self.env['einvoice.admin'].search([]):
                            self.admin_mail = self.env['einvoice.admin'].search([])[-1].name.id
                            template_id = self.env['mail.template'].sudo().search(
                                [('name', '=', 'Invoice: Send by email B2C')]).id
                            if template_id:
                                template = self.env['mail.template'].browse(template_id)
                                template.send_mail(self.id, force_send=True)
                            else:
                                raise UserError(
                                    'Please Create an Email Template In the name "Invoice: Send by email B2C" by giving PDF as Default B2C Formate')
                        else:
                            raise UserError('Please Configure the Admin Details to whom the mail need to be sended')
                    if configuration.invoice_print == True:
                        # return self.env.ref('account_invoice_ubl.account_invoices_b2c').report_action(self)
                        return self.env.ref('natcom_einvoice_report.natcom_einvoice_report').report_action(self)
        else:
            ''
        return res



    def print_einvoice(self):
        return self.env.ref('natcom_einvoice_report.natcom_einvoice_report').report_action(self)
        # --WITHOUT QR--

    #
    # def total_tax(self):
    #     total_tax_amount = self.amount_untaxed * 0.15
    #     return total_tax_amount

    # def ar_total_tax(self):
    #     value = self.amount_untaxed * 0.15
    #     before, after = str(value).split('.')
    #     before_int = int(before)
    #     after_int = int(after)
    #     before_ar = convert_numbers.english_to_arabic(before_int)
    #     after_ar = convert_numbers.english_to_arabic(after_int)
    #     ar_total_tax_amount = before_ar + '.' + after_ar + ' SR'
    #     print(ar_total_tax_amount,'jnjknkjn')
    #     return before_ar + '.' + after_ar + ' SR'

    def ar_advance(self):
        value = 0.00
        before, after = str(value).split('.')
        before_int = int(before)
        after_int = int(after)
        before_ar = convert_numbers.english_to_arabic(before_int)
        after_ar = convert_numbers.english_to_arabic(after_int)
        ar_total_tax_amount = before_ar + '.' + after_ar + ' SR'
        return before_ar + '.' + after_ar + ' SR'

    # def ar_invoice_name(self,name):
    #     translated = GoogleTranslator(source='auto', target='ar').translate(name)
    #     print(translated,'name')
    #     return translated

    def ar_invoice_name(self,name):

        interger_part = name[3:]
        interger_part_arabic = convert_numbers.english_to_arabic(interger_part)
        # inv_name_arabic = GoogleTranslator(source='auto', target='ar').translate(name[:3])
        inv_name_arabic = ""
        # return  inv_name_arabic+interger_part_arabic
        return  inv_name_arabic


    def ar_invoice_date(self):
        m = str(self.invoice_date)
        if m.split('-'):
            interger_part_arabic=''
            for each in m.split('-'):
                if interger_part_arabic:
                    interger_part_arabic = interger_part_arabic+'-'
                interger_part_arabic += convert_numbers.english_to_arabic(int(each))

        return interger_part_arabic

    def ar_mobile(self):
        a = self.partner_id.mobile
        ar_mobile = convert_numbers.english_to_arabic(a)
        return ar_mobile



    def total_amount_to_words_natcom(self):
        for invoice in self:
            return invoice.currency_id.amount_to_text(invoice.amount_untaxed)

    def total_amount_to_words_natcom_arabic(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_untaxed)
            # amount_arabic = GoogleTranslator(source='auto', target='ar').translate(amount_total_words)
            amount_arabic ="TESTING"
            return amount_arabic


    def total_amount_to_words_tax(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_total)
            return  amount_total_words

    def total_amount_to_words_tax_arabic(self):
        for invoice in self:
            amount_total_words = invoice.currency_id.amount_to_text(invoice.amount_total)
            # amount_total = GoogleTranslator(source='auto', target='ar').translate(amount_total_words)
            amount_total = "fddgdfgfd"
            return  amount_total

    # def total_amount_to_words(self):
    #     print(self.amount_total)
    #     check_amount_in_words = self.currency_id.amount_to_text(self.amount_total)
    #     print(check_amount_in_words)
    #     return check_amount_in_words


    def _ubl_add_attachments(self, parent_node, ns, version="2.1"):
        self.ensure_one()
        self.billing_refence(parent_node, ns, version="2.1")
        # if self.decoded_data:
        self.testing()
        self.qr_code(parent_node, ns, version="2.1")
        self.qr_1code(parent_node, ns, version="2.1")
        self.pih_code(parent_node, ns, version="2.1")

        # self.signature_refence(parent_node, ns, version="2.1")
        # if self.company_id.embed_pdf_in_ubl_xml_invoice and not self.env.context.get(
        #     "no_embedded_pdf"
        # ):
        # self.signature_refence(parent_node, ns, version="2.1")
        filename = "Invoice-" + self.name + ".pdf"
        docu_reference = etree.SubElement(
            parent_node, ns["cac"] + "AdditionalDocumentReference"
        )
        docu_reference_id = etree.SubElement(docu_reference, ns["cbc"] + "ID")
        docu_reference_id.text = filename
        attach_node = etree.SubElement(docu_reference, ns["cac"] + "Attachment")
        binary_node = etree.SubElement(
            attach_node,
            ns["cbc"] + "EmbeddedDocumentBinaryObject",
            mimeCode="application/pdf",
            filename=filename,
        )
        ctx = dict()
        ctx["no_embedded_ubl_xml"] = True
        ctx["force_report_rendering"] = True
        # pdf_inv = (
        #     self.with_context(ctx)
        #     .env.ref("account.account_invoices")
        #     ._render_qweb_pdf(self.ids)[0]
        # )
        ########changed########################
        pdf_inv = self.with_context(ctx).env.ref(
            'account_invoice_ubl.account_invoices_1')._render_qweb_pdf(self.ids)[0]
        pdf_inv = self.with_context(ctx).env.ref(
            'account_invoice_ubl.account_invoices_b2b')._render_qweb_pdf(self.ids)[0]
        pdf_inv = self.with_context(ctx).env.ref(
            'account_invoice_ubl.account_invoices_b2b_credit')._render_qweb_pdf(self.ids)[0]
        # pdf_inv = self.with_context(ctx).env.ref(
        #     'account_invoice_ubl.account_invoices_b2b_debit')._render_qweb_pdf(self.ids)[0]
        pdf_inv = self.with_context(ctx).env.ref(
            'account_invoice_ubl.account_invoices_b2c')._render_qweb_pdf(self.ids)[0]
        pdf_inv = self.with_context(ctx).env.ref(
                    'account_invoice_ubl.account_invoices_b2c_credit')._render_qweb_pdf(self.ids)[0]







        # +++++++++++++++++++++++++++++++OUR CUSTOMES ADD HERE+++++++++++++++++++++++++++++++++++++
        pdf_inv = self.with_context(ctx).env.ref(
            'natcom_einvoice_report.natcom_einvoice_report')._render_qweb_pdf(self.ids)[0]
        pdf_inv = self.with_context(ctx).env.ref(
            'natcom_einvoice_report.natcom_einvoice_report_no_header')._render_qweb_pdf(self.ids)[0]




       # -----------------------------aboveeeeeeee---------------------------------

        binary_node.text = base64.b64encode(pdf_inv)
        # self.qr3_code(parent_node, ns, version="2.1")


        # filename = "ICV"
        # icv_reference = etree.SubElement(
        #     parent_node, ns["cac"] + "AdditionalDocumentReference"
        # )
        # icv_reference_id = etree.SubElement(icv_reference, ns["cbc"] + "ID")
        # icv_reference_id.text = filename
        # icv_reference_node = etree.SubElement(icv_reference, ns["cac"] + "UUID")
        # icv_reference_node.text = self.name


    @api.model
    def _get_invoice_report_names(self):
        return [
            "account.report_invoice",
            "account.report_invoice_with_payments",
            "account_invoice_ubl.report_invoice_1",
            "account_invoice_ubl.report_invoice_b2b",
            "account_invoice_ubl.report_invoice_b2b_credit",
            "account_invoice_ubl.report_invoice_b2b_debit",
            "account_invoice_ubl.report_invoice_b2c",
            "account_invoice_ubl.report_invoice_b2c_credit",
            "account_invoice_ubl.report_invoice_b2c_debit",
            "natcom_einvoice_report.natcom_einvoice_report_view",
            "natcom_einvoice_report.natcom_einvoice_report_view_no_header"


        ]



class ResPartnerBank(models.Model):
    _inherit = 'res.partner.bank'
    # _inherit = 'res.partner.bank'

    iban_no_usd = fields.Char('IBAN No(USD)')
    ben_acc_no = fields.Char('Ben Acc No(USD)')




class ResCompany(models.Model):
    _inherit = 'res.company'

    image_footer = fields.Image()






class IrActionsReport(models.Model):
    _inherit = "ir.actions.report"


    @classmethod
    def _get_invoice_reports_ubl(cls):
        return [
            "account.report_invoice",
            'account_invoice_ubl.report_invoice_1',
            'account_invoice_ubl.report_invoice_b2b',
            'account_invoice_ubl.report_invoice_b2b_credit',
            'account_invoice_ubl.report_invoice_b2b_debit',
            'account_invoice_ubl.report_invoice_b2c',
            'account_invoice_ubl.report_invoice_b2c_credit',
            'account_invoice_ubl.report_invoice_b2c_debit',
            "account.report_invoice_with_payments",
            "account.account_invoice_report_duplicate_main",
            "natcom_einvoice_report.natcom_einvoice_report_view",
            "natcom_einvoice_report.natcom_einvoice_report_view_no_header",

        ]
